This directory of the GLScene CVS contains programs, libraries,
source code and utilities in general that are not part of GLScene,
but can help, simplify or improve use of GLScene.

Unless specified otherwise, they are all under Copyright of
Eric Grange and distributed under GNU GPL.
Active contributors (to the source, the testing, the benchmarking,
the documentation, etc.) may be granted free commercial use in
their products (without source publication restrictions of GPL),
if that's your case, mail in your details.

Eric Grange
egrange@glscene.org