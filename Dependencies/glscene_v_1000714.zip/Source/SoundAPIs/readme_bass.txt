  BASS 1.6a Multimedia Library
  -----------------------------
  (c) 1999-2002 Ian Luck.
  Please report bugs/suggestions/etc... to bass@un4seen.com

  Questions, suggestions, etc. regarding the Delphi API
  can be sent to magicrt@hotmail.com

  See the BASS.CHM file for more complete documentation

  NOTE: This unit will only work with BASS.DLL version 1.6a
  Check http://www.un4seen.com/music/ for any later
  versions of BASS.PAS