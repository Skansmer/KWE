====================================================
FMOD Sound/Music API for Windows 95/98/NT
VERSION 3.7
Copyright (c) FireLight Multimedia 1999-2003
See http://www.fmod.org for more information
====================================================

Installation :

* Win9x : Place "fmod.dll" in your Windows\System directory
* WinNT : Place "fmod.dll" in your Windows\System32 directory

Interface unit used here is the dynamically-linked version
by Steve Williams (stevewilliams@kromestudios.com)